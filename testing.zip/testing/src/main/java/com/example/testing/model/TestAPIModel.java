package com.example.testing.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.Map;

@Data
@AllArgsConstructor
@Builder
public class TestAPIModel {

    private String httpMethod;
    private String url;
    private Map<String, Object> headers;
    private Map<String, Object> queryParams;
    private Object requestBody;
    private Object expectedResponseBody;
    private int expectedResponseCode;

}
