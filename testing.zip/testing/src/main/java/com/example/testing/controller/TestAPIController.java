package com.example.testing.controller;

import com.example.testing.model.TestAPIModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/test")
public class TestAPIController {

    @Autowired
    private RestTemplate restTemplate;

    @PostMapping("/callAPI")
    public ResponseEntity<Object> callAPI(@RequestBody TestAPIModel testAPIModel) {
        String url = testAPIModel.getUrl();
        Object requestBody = testAPIModel.getRequestBody();
        ResponseEntity<Object> response = null;

        switch (testAPIModel.getHttpMethod().toUpperCase()) {
            case "POST":
                response = restTemplate.postForEntity(url, requestBody, Object.class);
                break;
            case "GET":
                response = restTemplate.getForEntity(url, Object.class);
                break;
            case "DELETE":
                restTemplate.delete(url);
                response = ResponseEntity.noContent().build();
                break;
            default:
                return ResponseEntity.badRequest().body("Invalid HTTP method");
        }

        return ResponseEntity.status(testAPIModel.getExpectedResponseCode()).body(response.getBody());
    }
}
